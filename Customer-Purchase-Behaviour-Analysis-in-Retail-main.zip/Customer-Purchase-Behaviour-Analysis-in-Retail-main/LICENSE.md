# License: All Rights Reserved

This project and all its contents are the intellectual property of the author.

Unauthorized copying, reproduction, or commercial use of any part of this repository is strictly prohibited without explicit permission from the author.

© 2025 Ayesha Banu. All rights reserved.
